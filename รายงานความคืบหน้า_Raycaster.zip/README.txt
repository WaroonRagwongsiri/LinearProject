Compile settings for report.tex
================================
Engine      : XeLaTeX  (required: uses fontspec + ICU Thai word breaking)
              NOT pdfLaTeX, NOT LuaLaTeX
Passes      : run twice (cross-references and section numbers)
Command     : xelatex report.tex && xelatex report.tex
Encoding    : UTF-8
Folder      : keep report.tex, fonts/ and images/ together (relative paths)

Overleaf    : Menu -> Compiler = XeLaTeX, Main document = report.tex
VS Code     : LaTeX Workshop -> use a recipe with xelatex (run twice)
TeXstudio   : Options -> Configure -> Build -> Default Compiler = XeLaTeX

Packages    : extsizes(extarticle), geometry, amsmath, amssymb, fontspec, graphicx,
              float, enumitem, indentfirst, needspace, titlesec, caption, hyperref
Font        : Laksaman (fonts/Laksaman*.otf, TLWG, Sarabun-derived, has Thai mark
              positioning tables). License: fonts/Laksaman-LICENSE.txt
Key settings: body 13pt, fixed 17.5 pt line pitch (\lineskiplimit=-30pt, parskip=0),
              \XeTeXlinebreaklocale "th"
